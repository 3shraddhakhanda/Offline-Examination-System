package project;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.plaf.ProgressBarUI;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.Icon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import java.awt.TextArea;
import javax.swing.JTextArea;
import javax.swing.JProgressBar;
import javax.swing.JButton;
import javax.swing.LayoutStyle.ComponentPlacement;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;
import java.awt.TextField;
import javax.swing.JRadioButton;
import javax.swing.JCheckBox;
import javax.swing.ButtonGroup;

public class Test extends JFrame
{

	private JPanel contentPane;
	private JTextField textField;

	JRadioButton rdbtnA = new JRadioButton();
	
	JRadioButton rdbtnB = new JRadioButton();
	
	JRadioButton rdbtnC = new JRadioButton();
	
	JRadioButton rdbtnD = new JRadioButton();
	
	JButton btnSubmitTest = new JButton("Submit Test");
	JProgressBar progressBar = new JProgressBar(0,1000);

	boolean flag=false;
	//static int score;
	TextArea textArea;
	/**
	 * Launch the application.
	 */
	
	/*public static void main(String[] args) 
	{
	
		Test frame = new Test();
		frame.setVisible(true);
		frame.set1();
	}*/
	String qid,question,o1,o2,o3,o4,ca;
	static int i=1,j;
	public static int corans=0;
	private final ButtonGroup buttonGroup = new ButtonGroup();
//	private final ButtonGroup buttonGroup_1 = new ButtonGroup();

	public void getQuestion()
	{
		Connection con=DBInfo.con;
		String query="select * from ques_java where q_id=?";
		try
		{
			PreparedStatement ps=con.prepareStatement(query);
			ps.setInt(1,i);
		
			ResultSet res=ps.executeQuery();
			while(res.next())
			{
				qid=res.getString(1);
				question=res.getString(2);
				o1=res.getString(3);
				o2=res.getString(4);
				o3=res.getString(5);
				o4=res.getString(6);
				ca=res.getString(7);
				i++;
				j=i;
				System.out.println(j);
			}
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

	/**
	 * Create the frame.
	 */
	public void  set1()
	{
	int s=0;
	while(s<1000)
	{
	
		s+=1;
		progressBar.setValue(s);
		
		try
		{
		
		Thread.sleep(10);	
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
	public Test() 
	{
		int i=0;
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 714, 558);
		setLocationRelativeTo(this);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		JLabel lblTime = new JLabel("Time -5:00");
		lblTime.setFont(new Font("ARAIL BLACK",Font.BOLD,12));
			progressBar.setValue(0);
			progressBar.setForeground(Color.green);
			progressBar.setStringPainted(true);
			add(progressBar);
			
			progressBar.setVisible(true);
			//set1();
		JLabel lblQuestionId = new JLabel("Question no.");
		lblQuestionId.setFont(new Font("ARIAL BLACK",Font.BOLD,12));
		getQuestion();

		textField = new JTextField(qid);
		textField.setForeground(Color.BLUE);
		textField.setEditable(false);
		textField.setColumns(10);
		JLabel lblQuestion = new JLabel("Question");
		lblQuestion.setFont(new Font("ARIAL BLACK",Font.BOLD,12));
		
		JLabel lblNewLabel = new JLabel(question);
		
		
		buttonGroup.add(rdbtnA);
		rdbtnA.setText(o1);
		buttonGroup.add(rdbtnB);
		rdbtnB.setText(o2);
		buttonGroup.add(rdbtnC);
		rdbtnC.setText(o3);
		buttonGroup.add(rdbtnD);
		rdbtnD.setText(o4);

		JButton btnNext = new JButton("NEXT");
		btnNext.setFont(new Font("ARIAL BLACK",Font.BOLD,12));
		
		btnNext.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent arg0) 
			{
			
				int ca = getCorrectAnswer(Integer.parseInt(qid));
				if(rdbtnA.isSelected())
				{
					if(ca==1)
						corans++;
				}
				else if(rdbtnB.isSelected())
				{
					if(ca==2)
						corans++;
				}
				else if(rdbtnC.isSelected())
				{
					if(ca==3)
						corans++;
				}
				else if(rdbtnD.isSelected())
				{
					if(ca==4)
						corans++;
				}
				
				//System.out.println("Correct Ans=" +ca + " And total corrected answers are  " + corans );
				if(rdbtnA.isSelected()==false&&rdbtnB.isSelected()==false&&rdbtnC.isSelected()==false&&rdbtnD.isSelected()==false)
				{
					JOptionPane.showMessageDialog(getParent(),"Select one answer");
				}	
				else
				{
				getQuestion();
				textField.setText(qid+"");
				lblNewLabel.setText(question);
				
				rdbtnA.setText(o1);
				rdbtnB.setText(o2);
				rdbtnC.setText(o3);
				rdbtnD.setText(o4);
				if(j==21)
				{
					JOptionPane.showMessageDialog(Test.this,"Click submit button","Test Completed",JOptionPane.INFORMATION_MESSAGE);
				}
				}
			}
			private int getCorrectAnswer(int qid)
			{
				int ans=0;
				try
				{
				
					Connection con=DBInfo.con;
					String query="select * from ques_java where q_id=?";
					PreparedStatement ps=con.prepareStatement(query);
					ps.setInt(1,qid);
								
					ResultSet res=ps.executeQuery();
					if(res.next())
					ans=Integer.parseInt(res.getString("correct_ans"));
						
					
					
				}
				catch(Exception ex)
				{
					ex.printStackTrace();
				}
				
				return ans;
			}
		});
		
		
		JButton btnSubmitTest = new JButton("Submit Test");
		btnSubmitTest.setFont(new Font("ARIAL BLACK",Font.BOLD, 12));
		btnSubmitTest.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent arg0)
			{
				if(j==21)
				{
				
				setEnabled(true);
				System.out.println("value="+corans);
				new result().setVisible(true);
				}
				else
				{
					
				}
			}
		});
		
		
		
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(32)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(rdbtnD)
						.addComponent(rdbtnC)
						.addComponent(rdbtnB)
						.addComponent(rdbtnA)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addComponent(lblTime)
							.addGap(38)
							.addComponent(progressBar, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(112)
							.addComponent(btnNext)
							.addPreferredGap(ComponentPlacement.RELATED, 175, Short.MAX_VALUE)
							.addComponent(btnSubmitTest)
							.addGap(163))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addComponent(lblQuestionId)
								.addComponent(lblQuestion))
							.addPreferredGap(ComponentPlacement.RELATED)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addComponent(textField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
								.addComponent(lblNewLabel, GroupLayout.PREFERRED_SIZE, 564, GroupLayout.PREFERRED_SIZE))))
					.addContainerGap())
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblTime)
						.addComponent(progressBar, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(32)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblQuestionId)
						.addComponent(textField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(44)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblQuestion)
						.addComponent(lblNewLabel))
					.addGap(100)
					.addComponent(rdbtnA)
					.addGap(26)
					.addComponent(rdbtnB)
					.addGap(18)
					.addComponent(rdbtnC)
					.addPreferredGap(ComponentPlacement.RELATED, 14, Short.MAX_VALUE)
					.addComponent(rdbtnD)
					.addPreferredGap(ComponentPlacement.RELATED, 53, Short.MAX_VALUE)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnNext)
						.addComponent(btnSubmitTest))
					.addGap(44))
		);
		contentPane.setLayout(gl_contentPane);
	}
}
