package project;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.plaf.ColorChooserUI;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JComboBox;
import javax.swing.JButton;
import javax.swing.JColorChooser;
import javax.swing.ButtonGroup;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextArea;

public class Student extends JFrame {

	private JPanel contentPane;
	private final ButtonGroup buttonGroup = new ButtonGroup();
	private final ButtonGroup buttonGroup_1 = new ButtonGroup();
	Test t=new Test();
	
	/**
	 * Launch the application.
	 */
	/*public static void main(String[] args)
	{
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Student frame = new Student();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}*/

	/**
	 * Create the frame.
	 */
	public Student() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setLocationRelativeTo(this);
		setBounds(100, 100, 638, 555);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setBackground(Color.lightGray);
		JLabel lblNewLabel = new JLabel("New label");
		
		JLabel lblSelectCourse = new JLabel("Select Course");
		lblSelectCourse.setFont(new Font("ARIAL BLACK",Font.BOLD,12));
		String course[]={"Select","C","C++","JAVA"};
		JComboBox comboBox = new JComboBox(course);
		comboBox.setFont(new Font("ARIAL ",Font.BOLD,12));
		
		JButton btnStartTest = new JButton("Start Test");
		btnStartTest.setFont(new Font("ARIAL BLACK",Font.BOLD,12));
		btnStartTest.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent arg0) 
			{
				
				String Option=(String) comboBox.getSelectedItem();
				if(Option.equalsIgnoreCase("select"))
				{
					
					JOptionPane.showMessageDialog(getParent(), "Select any course!!");
				}
				if(Option.equalsIgnoreCase("C++"))
				{	
					dispose();
				
					new Test1().setVisible(true);
				}
				if(Option.equalsIgnoreCase("Java"))
				{	
					dispose();
					new Test().setVisible(true);
					t.set1();
				}
				if(Option.equalsIgnoreCase("C"))
				{
					dispose();
					new Test2().setVisible(true);
				}
			}
		});
		
		JLabel lblTermsAndConditions = new JLabel("Terms and Conditions:");
		lblTermsAndConditions.setFont(new Font("ARIAL BLACK",Font.BOLD,12));
		
		
		JTextArea textArea = new JTextArea("1.There are 20 questions in this test\n\n2.You will have 5 minutes to complete 20 questions\n\n3. Clicking the SUBMIT button will display the \nresult.\n\n4.The time counter begins when you click \nthe START TEST button.\n\n\n\tBEST OF LUCK");
		textArea.setBackground(Color.lightGray);
		textArea.setFont(new Font("ARIAL",Font.BOLD,12));
		textArea.setEditable(false);
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(183)
							.addComponent(btnStartTest, GroupLayout.PREFERRED_SIZE, 191, GroupLayout.PREFERRED_SIZE))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(20)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addComponent(lblTermsAndConditions)
								.addComponent(lblSelectCourse))
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addComponent(comboBox, GroupLayout.PREFERRED_SIZE, 93, GroupLayout.PREFERRED_SIZE)
								.addComponent(textArea, GroupLayout.PREFERRED_SIZE, 415, Short.MAX_VALUE))))
					.addContainerGap())
				.addGroup(Alignment.TRAILING, gl_contentPane.createSequentialGroup()
					.addContainerGap(280, Short.MAX_VALUE)
					.addComponent(lblNewLabel)
					.addGap(236))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addComponent(lblNewLabel)
					.addGap(32)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblSelectCourse)
						.addComponent(comboBox, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(35)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(textArea, GroupLayout.PREFERRED_SIZE, 208, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblTermsAndConditions))
					.addPreferredGap(ComponentPlacement.RELATED, 136, Short.MAX_VALUE)
					.addComponent(btnStartTest, GroupLayout.PREFERRED_SIZE, 34, GroupLayout.PREFERRED_SIZE)
					.addGap(20))
		);
		contentPane.setLayout(gl_contentPane);
	}
}
