package project;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Image;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.Vector;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.TableColumnModel;
import javax.swing.table.TableModel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.GroupLayout;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class result extends JFrame {

	private JPanel contentPane;
	Test t=new Test();
	float cns=0;
	
	/**
	 * Launch the application.
	 */
	/*public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					result frame = new result();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}*/

	/**
	 * Create the frame.
	 */
	int ta;
	
	public void totalQuestion()
	{
		Connection con=DBInfo.con;
		String query="Select q_id from ques_java ";
		try
		{
			PreparedStatement ps=con.prepareStatement(query);
			ResultSet res=ps.executeQuery();
			while(res.next())
			{
				ta=res.getInt(1);
							
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

	int count=0,i;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	public result()
	{
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 525, 441);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JLabel lblAttemptedQuestion = new JLabel("Total questions");
		lblAttemptedQuestion.setFont(new Font("ARIAL BLACK",Font.BOLD,12));
		
		JLabel lblCorrectedQuestion = new JLabel("Corrected questions");
		lblCorrectedQuestion.setFont(new Font("ARIAL BLACK",Font.BOLD,12));
		
		JLabel lblWrongQuestion = new JLabel("Wrong questions");
		lblWrongQuestion.setFont(new Font("ARIAL BLACK",Font.BOLD,12));
		
		JLabel lblPercentage = new JLabel("Percentage");
		lblPercentage.setFont(new Font("ARIAL BLACK",Font.BOLD,12));

		totalQuestion();
		textField = new JTextField(ta+"");
		textField.setColumns(10);
		
		//System.out.println("value of ="+t.corans);
		cns=t.corans;
		textField_1 = new JTextField((int)cns+"");
		textField_1.setColumns(10);
		if(cns>=18)
		{
			JOptionPane.showMessageDialog(result.this,"Awesome!!","Remark", JOptionPane.PLAIN_MESSAGE);
		}
		else if(cns>10 && cns<17)
		{
			JOptionPane.showMessageDialog(result.this,"Good!!","Remark", JOptionPane.PLAIN_MESSAGE);
		}
		else if(cns>1 && cns<10)
		{
			JOptionPane.showMessageDialog(result.this,"Need to improve!!","Remark", JOptionPane.PLAIN_MESSAGE);
		}
		
		int wa=(int) (ta-cns);
		textField_2 = new JTextField(wa+"");
		textField_2.setColumns(10);
		float per=(cns/ta)*100;
		//System.out.println("per="+cns);
		textField_3 = new JTextField(per+"");
		textField_3.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("");
		Image img=new ImageIcon(this.getClass().getResource("/report.png")).getImage();
		lblNewLabel_1.setIcon(new ImageIcon(img));
		
		JButton btnViewAnswerKey = new JButton("View Answer key");
		btnViewAnswerKey.setFont(new Font("ARIAL BLACK",Font.BOLD,12));
		btnViewAnswerKey.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent arg0)
			{
				Vector<String> col=new Vector<>();
				 col.add("Question id");
				 col.add("question");
				 col.add("option 1");
				 col.add("option 2");
				 col.add("option3");
				 col.add("option 4");
				 col.add("Correct ans");
				 Connection con=DBInfo.con;
				 String query="Select * from ques_java";
				 try
				 {
					 PreparedStatement ps=con.prepareStatement(query);
					 ResultSet rs=ps.executeQuery();
					 Vector<Vector<String>> m=new Vector<>();
					 Vector<String> row=new Vector<>();
					 ResultSetMetaData rsmd=rs.getMetaData();
					 int c=rsmd.getColumnCount();
					 while(rs.next())
					 {
						 row=new Vector<>(c);
						 for(int i=1;i<=c;i++)
						 {
							 row.add(rs.getString(i));
							 
						 }
						 m.add(row);
					 }
					 JFrame f=new JFrame("View Answer key");
					 f.setResizable(false);
					 f.setTitle("View Answers");
					 f.setSize(getToolkit().getScreenSize());
					 JTable t=new JTable(m,col);
					 t.setEnabled(false);
					 JScrollPane pane=new JScrollPane(t);
					 f.getContentPane().add(pane);
					 
					 f.setVisible(true);
					 
				 }
				 catch(Exception e)
				 {
					 e.printStackTrace();
				 }
	

			}
		});
		
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(99)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addComponent(lblAttemptedQuestion)
								.addComponent(lblCorrectedQuestion)
								.addComponent(lblWrongQuestion)
								.addComponent(lblPercentage))
							.addGap(58)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addComponent(textField_3, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
								.addComponent(textField_2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
								.addComponent(textField_1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
								.addComponent(textField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(178)
							.addComponent(lblNewLabel_1, GroupLayout.PREFERRED_SIZE, 66, GroupLayout.PREFERRED_SIZE))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(175)
							.addComponent(btnViewAnswerKey)))
					.addContainerGap(159, Short.MAX_VALUE))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addComponent(lblNewLabel_1, GroupLayout.DEFAULT_SIZE, 78, Short.MAX_VALUE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(lblAttemptedQuestion)
						.addComponent(textField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(38)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addComponent(lblCorrectedQuestion)
							.addGap(44)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
								.addComponent(lblWrongQuestion)
								.addComponent(textField_2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
							.addGap(40)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
								.addComponent(lblPercentage)
								.addComponent(textField_3, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)))
						.addComponent(textField_1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(55)
					.addComponent(btnViewAnswerKey)
					.addGap(35))
		);
		contentPane.setLayout(gl_contentPane);
	}
}
